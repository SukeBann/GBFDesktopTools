﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UIBrowser.Core
{
    public abstract class ViewModelBase : Screen
    {
        #region Ctor
        public ViewModelBase()
        {
        }
        #endregion
    }
}
