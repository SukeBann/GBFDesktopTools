﻿namespace UIBrowser.Components
{
    public enum Sex
    {
        Male,
        Female,
        Others,
    }
}
