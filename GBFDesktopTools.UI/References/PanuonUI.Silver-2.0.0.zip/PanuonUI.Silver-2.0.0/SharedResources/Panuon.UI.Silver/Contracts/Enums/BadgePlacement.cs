﻿namespace Panuon.UI.Silver
{
    public enum BadgePlacement
    {
        Strench,
        Center,
        TopLeft,
        TopRight,
        BottomRight,
        BottomLeft,
    }
}
