﻿namespace Panuon.UI.Silver
{
    public enum CalendarXMode
    {
        Date,
        Year,
        YearMonth,
        MultipleDate,
        DateRange,
    }
}
