﻿namespace Panuon.UI.Silver
{
    public enum ColorSelectorPanels
    {
        All,
        Value,
        DefaultPalette,
        None,
    }
}
