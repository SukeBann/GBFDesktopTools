﻿namespace Panuon.UI.Silver
{
    public enum LoadingSpeed
    {
        Normal,
        Slow,
        Quick,
    }
}
