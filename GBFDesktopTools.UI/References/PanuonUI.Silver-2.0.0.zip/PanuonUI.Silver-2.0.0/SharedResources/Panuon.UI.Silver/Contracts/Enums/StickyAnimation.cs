﻿namespace Panuon.UI.Silver
{
    public enum StickyAnimation
    {
        Scale,
        Slide,
    }
}
