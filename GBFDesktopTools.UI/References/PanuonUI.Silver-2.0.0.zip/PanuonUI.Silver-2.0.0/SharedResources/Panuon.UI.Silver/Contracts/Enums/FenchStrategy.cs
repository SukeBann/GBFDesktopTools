﻿namespace Panuon.UI.Silver
{
    public enum FenchStrategy
    {
        Free,
        Edged,
        Crossed
    }
}
