﻿namespace Panuon.UI.Silver
{
    public enum SignboardAnimation
    {
        Notice,
        Marble,
        Barrage,
        Fade,
    }
}
