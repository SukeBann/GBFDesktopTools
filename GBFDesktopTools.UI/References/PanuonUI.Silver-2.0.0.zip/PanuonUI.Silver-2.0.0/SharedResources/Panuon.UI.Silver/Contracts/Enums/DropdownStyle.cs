﻿namespace Panuon.UI.Silver
{
    public enum DropDownStyle
    {
        Standard,
        Smooth,
    }
}
