﻿namespace Panuon.UI.Silver
{
    public enum DrawerPlacement
    {
        Left,
        Top,
        Right,
        Bottom,
    }
}
