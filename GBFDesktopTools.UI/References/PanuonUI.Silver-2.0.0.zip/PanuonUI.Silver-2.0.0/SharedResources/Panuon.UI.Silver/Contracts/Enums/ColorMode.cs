﻿namespace Panuon.UI.Silver
{
    public enum ColorMode
    {
        Argb,
        Rgb,
    }
}
