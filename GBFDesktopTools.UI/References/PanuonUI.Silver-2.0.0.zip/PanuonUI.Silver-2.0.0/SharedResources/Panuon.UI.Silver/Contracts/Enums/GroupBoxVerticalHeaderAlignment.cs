﻿namespace Panuon.UI.Silver
{
    public enum GroupBoxVerticalHeaderAlignment
    {
        Top,
        Bottom,
    }
}
