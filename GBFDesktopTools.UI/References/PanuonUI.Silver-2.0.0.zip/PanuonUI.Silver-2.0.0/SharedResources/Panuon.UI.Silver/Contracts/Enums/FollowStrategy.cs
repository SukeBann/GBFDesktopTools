﻿namespace Panuon.UI.Silver
{
    public enum FollowStrategy
    {
        None,
        ParentWindow,
    }
}
