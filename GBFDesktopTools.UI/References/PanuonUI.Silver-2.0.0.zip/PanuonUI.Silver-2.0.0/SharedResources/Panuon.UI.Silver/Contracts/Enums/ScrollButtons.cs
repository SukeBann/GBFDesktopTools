﻿namespace Panuon.UI.Silver
{
    public enum ScrollButtons
    {
        None,
        UpDown,
        TopBottom,
        All,
    }
}
