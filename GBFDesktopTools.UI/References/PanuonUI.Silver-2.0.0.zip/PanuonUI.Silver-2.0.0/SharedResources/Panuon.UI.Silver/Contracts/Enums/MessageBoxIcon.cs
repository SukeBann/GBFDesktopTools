﻿namespace Panuon.UI.Silver
{
    public enum MessageBoxIcon
    {
        None,
        Info,
        Warning,
        Error,
        Success,
        Question,
    }
}
