﻿namespace Panuon.UI.Silver
{
    public enum ClickStyle
    {
        None,
        Sink,
    }
}
