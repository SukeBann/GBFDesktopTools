﻿namespace Panuon.UI.Silver
{
    public enum DefaultButton
    {
        Unset,
        YesOK,
        NoCancel,
        CancelNo
    }
}
