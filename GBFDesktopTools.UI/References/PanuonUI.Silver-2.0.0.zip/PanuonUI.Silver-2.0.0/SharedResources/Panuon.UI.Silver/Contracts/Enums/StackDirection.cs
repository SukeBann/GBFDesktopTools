﻿namespace Panuon.UI.Silver
{
    public enum StackDirection
    {
        Normal,
        Reverse,
    }
}
