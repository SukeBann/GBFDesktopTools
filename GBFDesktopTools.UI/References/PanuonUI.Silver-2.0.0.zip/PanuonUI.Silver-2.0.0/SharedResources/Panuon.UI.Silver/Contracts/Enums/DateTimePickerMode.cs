﻿namespace Panuon.UI.Silver
{
    public enum DateTimePickerMode
    {
        Date,
        Year,
        YearMonth,
        DateTime,
        Time,
    }
}
