﻿namespace Panuon.UI.Silver
{
    public enum IconPlacement
    {
        Left,
        Top,
    }
}
