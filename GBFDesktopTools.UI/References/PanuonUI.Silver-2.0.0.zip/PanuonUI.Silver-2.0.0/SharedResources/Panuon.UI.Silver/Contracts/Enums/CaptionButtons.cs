﻿namespace Panuon.UI.Silver
{
    public enum CaptionButtons
    {
        All,
        Close,
        MinimizeClose,
        MaximizeClose,
        None,
    }
}
