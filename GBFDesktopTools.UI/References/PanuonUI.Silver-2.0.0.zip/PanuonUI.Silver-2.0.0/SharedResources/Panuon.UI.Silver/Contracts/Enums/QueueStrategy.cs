﻿namespace Panuon.UI.Silver
{
    public enum QueueStrategy
    {
        Normal,
        Priority,
        None,
    }
}
