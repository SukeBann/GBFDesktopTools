﻿namespace Panuon.UI.Silver
{
    public enum MessageBoxButtonArrangement
    {
        /// <summary>
        /// Yes button on the left.
        /// </summary>
        Standard,
        /// <summary>
        /// Yes button on the right.
        /// </summary>
        Reverse,
    }
}
