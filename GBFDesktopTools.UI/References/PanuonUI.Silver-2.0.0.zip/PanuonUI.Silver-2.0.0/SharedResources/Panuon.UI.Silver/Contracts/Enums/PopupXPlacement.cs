﻿namespace Panuon.UI.Silver
{
    public enum PopupXPlacement
    {
        Left,
        TopLeft,
        Top,
        TopRight,
        Right,
        BottomRight,
        Bottom,
        BottomLeft,
    }
}
