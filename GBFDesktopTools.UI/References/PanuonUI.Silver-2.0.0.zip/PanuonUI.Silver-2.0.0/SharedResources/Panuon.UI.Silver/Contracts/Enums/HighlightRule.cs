﻿namespace Panuon.UI.Silver
{
    public enum HighlightRule
    {
        All,
        First,
    }
}
