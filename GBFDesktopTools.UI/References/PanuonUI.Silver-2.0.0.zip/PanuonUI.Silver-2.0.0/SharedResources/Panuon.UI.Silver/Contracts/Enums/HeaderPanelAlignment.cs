﻿namespace Panuon.UI.Silver
{
    public enum HeaderPanelAlignment
    {
        Front,
        Stretch,
        Center,
        End
    }
}