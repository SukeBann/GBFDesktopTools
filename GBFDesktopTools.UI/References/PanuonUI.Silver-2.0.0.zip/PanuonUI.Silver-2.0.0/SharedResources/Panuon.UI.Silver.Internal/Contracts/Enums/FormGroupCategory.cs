﻿namespace Panuon.UI.Silver.Internal
{
    enum FormGroupCategory
    {
        Text,
        ComboBox,
        CheckBox,
        Template

    }
}
