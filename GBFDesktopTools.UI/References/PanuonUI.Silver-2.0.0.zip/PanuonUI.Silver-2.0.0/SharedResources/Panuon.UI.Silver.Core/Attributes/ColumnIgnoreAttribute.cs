﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panuon.UI.Silver.Core
{
    public class ColumnIgnoreAttribute : Attribute
    {
        #region Ctor
        public ColumnIgnoreAttribute()
        {
        }
        #endregion
    }
}
