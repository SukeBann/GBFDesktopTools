﻿namespace Panuon.UI.Silver.Core
{
    public class NumberRange
    {
        public double From { get; set; } = 0;

        public double To { get; set; } = 1;

        public double Interval { get; set; } = 1;
    }
}
