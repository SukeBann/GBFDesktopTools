﻿using Panuon.UI.Silver.Internal.Utils;

namespace Panuon.UI.Silver.Core
{
    public class NoticeXSettings
    {
        #region Ctor
        public NoticeXSettings()
        {
        }
        #endregion

        #region Properties
        public bool CreateOnNewThread { get; set; } = true;
        #endregion
    }
}
