﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Panuon.UI.Silver.Core
{
    public sealed class CallerMemberNameAttribute : Attribute
    {

    }
}
