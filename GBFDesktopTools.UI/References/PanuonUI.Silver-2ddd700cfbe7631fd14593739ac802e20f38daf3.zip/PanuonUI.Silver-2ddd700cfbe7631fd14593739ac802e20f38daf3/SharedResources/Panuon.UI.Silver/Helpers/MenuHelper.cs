﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panuon.UI.Silver
{
    public static class MenuHelper
    {
        #region Properties

        #endregion
    }
}
