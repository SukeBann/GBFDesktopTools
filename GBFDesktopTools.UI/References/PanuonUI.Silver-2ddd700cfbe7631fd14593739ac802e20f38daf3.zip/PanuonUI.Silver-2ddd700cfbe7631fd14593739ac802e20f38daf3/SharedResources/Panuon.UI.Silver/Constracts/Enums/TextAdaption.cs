﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Panuon.UI.Silver
{
    public enum TextAdaption
    {
        None,
        ClipToBounds,
    }
}
