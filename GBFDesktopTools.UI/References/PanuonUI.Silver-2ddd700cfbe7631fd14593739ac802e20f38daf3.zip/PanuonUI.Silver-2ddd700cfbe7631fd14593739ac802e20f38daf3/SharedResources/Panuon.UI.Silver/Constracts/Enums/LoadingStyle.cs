﻿namespace Panuon.UI.Silver
{
    public enum LoadingStyle
    {
        Standard,
        Wave,
        Ring,
        Ring2,
        Classic
    }
}
