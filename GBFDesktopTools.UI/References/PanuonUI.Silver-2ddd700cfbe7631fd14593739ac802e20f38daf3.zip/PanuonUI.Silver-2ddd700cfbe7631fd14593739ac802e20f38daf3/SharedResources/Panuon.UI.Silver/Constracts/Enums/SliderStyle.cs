﻿namespace Panuon.UI.Silver
{
    public enum SliderStyle
    {
        Standard,
        Modern,
    }
}
