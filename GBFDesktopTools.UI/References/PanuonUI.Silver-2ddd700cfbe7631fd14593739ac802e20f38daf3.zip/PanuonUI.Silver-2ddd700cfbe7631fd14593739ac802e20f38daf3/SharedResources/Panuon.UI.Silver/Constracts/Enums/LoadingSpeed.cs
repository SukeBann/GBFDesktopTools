﻿namespace Panuon.UI.Silver
{
    public enum LoadingSpeed
    {
        Normal,
        Quick,
        Slow
    }
}
