﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panuon.UI.Silver
{
    public enum ProgressDirection
    {
        LeftToRight,
        RightToLeft,
        BottomToTop,
        TopToBottom,
    }
}
