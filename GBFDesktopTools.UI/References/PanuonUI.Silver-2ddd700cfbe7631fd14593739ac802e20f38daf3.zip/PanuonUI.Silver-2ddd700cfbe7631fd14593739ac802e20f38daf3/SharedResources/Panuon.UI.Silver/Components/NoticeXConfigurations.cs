﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panuon.UI.Silver
{
    public class NoticeXConfigurations
    {
        public bool CreateOnNewThread { get; set; } = true;
    }
}
