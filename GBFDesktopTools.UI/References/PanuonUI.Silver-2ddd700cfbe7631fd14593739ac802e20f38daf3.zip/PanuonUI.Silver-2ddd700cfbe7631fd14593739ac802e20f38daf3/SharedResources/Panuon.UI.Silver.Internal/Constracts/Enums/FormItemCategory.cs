﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Panuon.UI.Silver.Internal.Constracts.Enums
{
    internal enum FormItemCategory
    {
        Text,
        Password,
        CheckBox,
        RadioButton,
        Custom,
    }
}
