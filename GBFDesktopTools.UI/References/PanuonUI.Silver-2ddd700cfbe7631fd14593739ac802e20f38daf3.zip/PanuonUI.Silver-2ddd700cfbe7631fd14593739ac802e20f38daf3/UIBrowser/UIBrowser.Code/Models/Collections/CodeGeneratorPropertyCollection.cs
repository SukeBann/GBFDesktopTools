﻿using System.Collections.ObjectModel;

namespace UIBrowser.Code
{
    public class CodeGeneratorPropertyCollection : Collection<CodeGeneratorProperty>
    {
    }
}
